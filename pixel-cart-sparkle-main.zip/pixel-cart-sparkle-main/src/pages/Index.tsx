import { useState } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import FeaturesSection from "@/components/FeaturesSection";
import Cart from "@/components/Cart";
import LoginPage from "@/components/LoginPage";
import CheckoutPage from "@/components/CheckoutPage";
import TodoList from "@/components/TodoList";
import ProductCatalog from "@/components/ProductCatalog";
import { Toaster } from "@/components/ui/toaster";

const Index = () => {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isTodoOpen, setIsTodoOpen] = useState(false);
  const [isProductsOpen, setIsProductsOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [cartItemsCount, setCartItemsCount] = useState(3); // Mock cart count

  const handleGetStarted = () => {
    setIsCartOpen(true);
  };

  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handlePaymentSuccess = () => {
    setIsCheckoutOpen(false);
    setCartItemsCount(0);
    // In real app, redirect to success page or reset cart
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        cartItemsCount={cartItemsCount}
        onLoginClick={() => setIsLoginOpen(true)}
        onCartClick={() => setIsCartOpen(true)}
        onTodoClick={() => setIsTodoOpen(true)}
        onProductsClick={() => setIsProductsOpen(true)}
      />
      
      <main>
        <HeroSection onGetStarted={handleGetStarted} />
        <FeaturesSection />
      </main>

      {/* Modals/Overlays */}
      <Cart 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onCheckout={handleCheckout}
      />

      {isLoginOpen && (
        <LoginPage 
          onClose={() => setIsLoginOpen(false)}
          onLoginSuccess={handleLoginSuccess}
        />
      )}

      {isCheckoutOpen && (
        <CheckoutPage 
          onBack={() => {
            setIsCheckoutOpen(false);
            setIsCartOpen(true);
          }}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      <TodoList 
        isOpen={isTodoOpen}
        onClose={() => setIsTodoOpen(false)}
      />

      <ProductCatalog 
        isOpen={isProductsOpen}
        onClose={() => setIsProductsOpen(false)}
      />

      <Toaster />
    </div>
  );
};

export default Index;
