import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-cart.jpg";

interface HeroSectionProps {
  onGetStarted: () => void;
}

export default function HeroSection({ onGetStarted }: HeroSectionProps) {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Grocery Background */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Floating grocery items */}
        <div className="absolute top-20 left-10 text-3xl animate-bounce opacity-60 select-none">🍎</div>
        <div className="absolute top-40 right-20 text-2xl animate-pulse opacity-50 select-none">🥛</div>
        <div className="absolute top-60 left-1/4 text-2xl animate-bounce delay-500 opacity-40 select-none">🍞</div>
        <div className="absolute top-32 right-1/3 text-3xl animate-pulse delay-1000 opacity-60 select-none">🥚</div>
        <div className="absolute bottom-40 left-20 text-2xl animate-bounce delay-1500 opacity-50 select-none">🍌</div>
        <div className="absolute bottom-60 right-10 text-3xl animate-pulse delay-2000 opacity-40 select-none">🍅</div>
        <div className="absolute top-80 left-1/2 text-2xl animate-bounce delay-2500 opacity-60 select-none">🧅</div>
        <div className="absolute bottom-32 left-1/3 text-2xl animate-pulse delay-3000 opacity-50 select-none">🥕</div>
        <div className="absolute top-52 right-1/4 text-3xl animate-bounce delay-3500 opacity-40 select-none">🥬</div>
        <div className="absolute bottom-20 right-1/2 text-2xl animate-pulse delay-4000 opacity-60 select-none">🍗</div>
        
        {/* Animated background gradients */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-primary/10 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gradient-to-l from-primary-glow/10 to-transparent rounded-full blur-3xl animate-pulse delay-2000"></div>
        
        {/* Sparkle effects */}
        <div className="absolute top-16 left-16 w-1 h-1 bg-primary rounded-full animate-ping opacity-75"></div>
        <div className="absolute top-28 right-32 w-1 h-1 bg-primary-glow rounded-full animate-ping delay-1000 opacity-60"></div>
        <div className="absolute bottom-24 left-32 w-1 h-1 bg-primary rounded-full animate-ping delay-2000 opacity-80"></div>
        <div className="absolute bottom-48 right-16 w-1 h-1 bg-primary-glow rounded-full animate-ping delay-3000 opacity-70"></div>
      </div>

      <div className="container px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left hero-animation">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight mb-6">
              <span className="bg-gradient-primary bg-clip-text text-transparent animate-fade-in">
                Smart Cart AI
              </span>
            </h1>
            <p className="text-lg sm:text-xl lg:text-2xl text-muted-foreground mb-8 max-w-2xl animate-fade-in delay-300">
              🛒 Scan as you shop. Items appear in your cart automatically.
              <br />
              <span className="font-semibold text-foreground">
                💳 Checkout in-app and skip the queue.
              </span>
            </p>
            <p className="text-base text-muted-foreground mb-8 animate-fade-in delay-500">
              🔧 Works with Raspberry Pi device detection
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start animate-fade-in delay-700">
              <Button 
                size="lg"
                className="bg-gradient-primary hover:shadow-glow transition-all duration-300 text-lg px-8 py-6 hover:scale-105 transform relative overflow-hidden group"
                onClick={onGetStarted}
              >
                <span className="relative z-10">🚀 Start Shopping</span>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-600"></div>
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="text-lg px-8 py-6 hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-105 transform"
              >
                📖 Learn More
              </Button>
            </div>
          </div>

          {/* Right Content - Hero Image */}
          <div className="relative animate-fade-in delay-1000">
            <div className="relative z-10 transform hover:scale-105 transition-transform duration-500">
              <img
                src={heroImage}
                alt="Smart shopping cart with AI technology featuring daily groceries"
                className="w-full h-auto rounded-2xl shadow-2xl border border-primary/20"
              />
              
              {/* Floating action indicators */}
              <div className="absolute top-4 right-4 bg-primary/90 text-primary-foreground px-3 py-1 rounded-full text-sm font-medium animate-pulse">
                🤖 AI Powered
              </div>
              <div className="absolute bottom-4 left-4 bg-green-500/90 text-white px-3 py-1 rounded-full text-sm font-medium animate-bounce">
                ✅ Live Detection
              </div>
            </div>
            
            {/* Enhanced Decorative Elements */}
            <div className="absolute -top-8 -right-8 w-80 h-80 bg-gradient-to-br from-primary/20 to-primary-glow/20 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
            <div className="absolute -bottom-8 -left-8 w-80 h-80 bg-gradient-to-tr from-primary-glow/20 to-primary/20 rounded-full mix-blend-multiply filter blur-xl animate-pulse delay-1000"></div>
            
            {/* Shopping cart trail effect */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="w-2 h-2 bg-primary rounded-full animate-ping"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced trust indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="flex items-center gap-6 text-sm text-muted-foreground animate-fade-in delay-2000">
          <div className="flex items-center gap-2">
            <span className="text-green-500">🔒</span>
            <span>Secure Payments</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-blue-500">⚡</span>
            <span>Real-time Detection</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-purple-500">🎯</span>
            <span>Smart Suggestions</span>
          </div>
        </div>
      </div>
    </section>
  );
}