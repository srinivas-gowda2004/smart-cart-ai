import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Plus, Check, Trash2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface TodoItem {
  id: string;
  text: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
}

interface TodoListProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TodoList({ isOpen, onClose }: TodoListProps) {
  const [todos, setTodos] = useState<TodoItem[]>([
    { id: "1", text: "Buy fresh vegetables", completed: false, priority: "high" },
    { id: "2", text: "Get milk and eggs", completed: false, priority: "medium" },
    { id: "3", text: "Pick up bread from bakery", completed: true, priority: "low" },
  ]);
  const [newTodo, setNewTodo] = useState("");

  const addTodo = () => {
    if (newTodo.trim()) {
      const todo: TodoItem = {
        id: Date.now().toString(),
        text: newTodo.trim(),
        completed: false,
        priority: "medium"
      };
      setTodos([todo, ...todos]);
      setNewTodo("");
      toast({
        title: "✅ Todo Added!",
        description: "Your shopping item has been added to the list",
      });
    }
  };

  const toggleTodo = (id: string) => {
    setTodos(todos.map(todo => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id: string) => {
    setTodos(todos.filter(todo => todo.id !== id));
    toast({
      title: "🗑️ Todo Removed",
      description: "Item removed from your shopping list",
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'secondary';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md max-h-[80vh] overflow-hidden animate-scale-in">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-xl font-bold">Shopping Todo List</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="hover:bg-destructive/10 hover:text-destructive"
          >
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Add New Todo */}
          <div className="flex gap-2">
            <Input
              placeholder="Add shopping item..."
              value={newTodo}
              onChange={(e) => setNewTodo(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addTodo()}
              className="flex-1"
            />
            <Button 
              onClick={addTodo}
              className="hover:scale-105 transition-transform"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {/* Todo List */}
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {todos.map((todo) => (
              <div
                key={todo.id}
                className={`flex items-center gap-3 p-3 rounded-lg border transition-all duration-200 hover:shadow-md ${
                  todo.completed ? 'bg-muted/50' : 'bg-background'
                }`}
              >
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleTodo(todo.id)}
                  className={`p-1 h-6 w-6 rounded-full ${
                    todo.completed 
                      ? 'bg-primary text-primary-foreground' 
                      : 'border-2 border-muted-foreground hover:border-primary'
                  }`}
                >
                  {todo.completed && <Check className="h-3 w-3" />}
                </Button>
                
                <span 
                  className={`flex-1 ${
                    todo.completed 
                      ? 'line-through text-muted-foreground' 
                      : 'text-foreground'
                  }`}
                >
                  {todo.text}
                </span>
                
                <Badge variant={getPriorityColor(todo.priority) as any} className="text-xs">
                  {todo.priority}
                </Badge>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteTodo(todo.id)}
                  className="p-1 h-6 w-6 hover:bg-destructive/10 hover:text-destructive"
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>

          {todos.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <p>No items in your shopping list</p>
              <p className="text-sm">Add some groceries to get started!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}