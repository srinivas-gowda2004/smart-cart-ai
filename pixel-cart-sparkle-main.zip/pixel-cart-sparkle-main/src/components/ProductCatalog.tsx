import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { X, Search, ShoppingCart, Star } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
  rating: number;
  inStock: boolean;
}

interface ProductCatalogProps {
  isOpen: boolean;
  onClose: () => void;
}

const groceryProducts: Product[] = [
  { id: "1", name: "Fresh Apples", price: 4.99, category: "Fruits", image: "🍎", rating: 4.5, inStock: true },
  { id: "2", name: "Whole Milk", price: 3.49, category: "Dairy", image: "🥛", rating: 4.8, inStock: true },
  { id: "3", name: "Bread Loaf", price: 2.99, category: "Bakery", image: "🍞", rating: 4.3, inStock: true },
  { id: "4", name: "Eggs (12 pack)", price: 5.49, category: "Dairy", image: "🥚", rating: 4.7, inStock: true },
  { id: "5", name: "Bananas", price: 1.99, category: "Fruits", image: "🍌", rating: 4.6, inStock: true },
  { id: "6", name: "Rice (5kg)", price: 12.99, category: "Grains", image: "🍚", rating: 4.4, inStock: true },
  { id: "7", name: "Chicken Breast", price: 8.99, category: "Meat", image: "🍗", rating: 4.2, inStock: false },
  { id: "8", name: "Tomatoes", price: 3.99, category: "Vegetables", image: "🍅", rating: 4.5, inStock: true },
  { id: "9", name: "Onions", price: 2.49, category: "Vegetables", image: "🧅", rating: 4.3, inStock: true },
  { id: "10", name: "Olive Oil", price: 7.99, category: "Cooking", image: "🫒", rating: 4.9, inStock: true },
  { id: "11", name: "Pasta", price: 1.99, category: "Grains", image: "🍝", rating: 4.4, inStock: true },
  { id: "12", name: "Yogurt", price: 4.49, category: "Dairy", image: "🥛", rating: 4.6, inStock: true },
];

export default function ProductCatalog({ isOpen, onClose }: ProductCatalogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  
  const categories = ["All", "Fruits", "Dairy", "Bakery", "Vegetables", "Meat", "Grains", "Cooking"];
  
  const filteredProducts = groceryProducts.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const addToCart = (product: Product) => {
    if (!product.inStock) {
      toast({
        title: "❌ Out of Stock",
        description: `${product.name} is currently unavailable`,
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "✅ Added to Cart!",
      description: `${product.name} has been added to your cart`,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl max-h-[85vh] overflow-hidden animate-scale-in">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-2xl font-bold">Daily Grocery Products</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="hover:bg-destructive/10 hover:text-destructive"
          >
            <X className="h-5 w-5" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              {categories.map(category => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="hover:scale-105 transition-transform"
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-h-96 overflow-y-auto">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="hover:shadow-lg transition-all duration-200 hover:scale-105">
                <CardContent className="p-4">
                  <div className="text-center mb-3">
                    <div className="text-4xl mb-2">{product.image}</div>
                    <h3 className="font-semibold text-sm">{product.name}</h3>
                    <Badge variant="secondary" className="text-xs mt-1">
                      {product.category}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-center gap-1 mb-2">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-xs text-muted-foreground">{product.rating}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-primary">${product.price}</span>
                    <Button
                      size="sm"
                      onClick={() => addToCart(product)}
                      disabled={!product.inStock}
                      className={`hover:scale-110 transition-transform ${
                        !product.inStock ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                    >
                      <ShoppingCart className="h-3 w-3 mr-1" />
                      {product.inStock ? 'Add' : 'Out'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <p>No products found</p>
              <p className="text-sm">Try adjusting your search or filters</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}