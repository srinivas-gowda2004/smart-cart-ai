import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, ShoppingCart, User, Menu, X, ClipboardList } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
}

// Daily grocery items for search suggestions
const dailyGroceries: Product[] = [
  { id: "1", name: "Fresh Apples", price: 4.99, category: "Fruits" },
  { id: "2", name: "Whole Milk", price: 3.49, category: "Dairy" },
  { id: "3", name: "Bread Loaf", price: 2.99, category: "Bakery" },
  { id: "4", name: "Eggs (12 pack)", price: 5.49, category: "Dairy" },
  { id: "5", name: "Bananas", price: 1.99, category: "Fruits" },
  { id: "6", name: "Rice (5kg)", price: 12.99, category: "Grains" },
  { id: "7", name: "Chicken Breast", price: 8.99, category: "Meat" },
  { id: "8", name: "Tomatoes", price: 3.99, category: "Vegetables" },
  { id: "9", name: "Onions", price: 2.49, category: "Vegetables" },
  { id: "10", name: "Olive Oil", price: 7.99, category: "Cooking" },
  { id: "11", name: "Pasta", price: 1.99, category: "Grains" },
  { id: "12", name: "Yogurt", price: 4.49, category: "Dairy" },
  { id: "13", name: "Carrots", price: 2.99, category: "Vegetables" },
  { id: "14", name: "Butter", price: 5.99, category: "Dairy" },
  { id: "15", name: "Sugar", price: 3.99, category: "Pantry" },
];

interface HeaderProps {
  cartItemsCount?: number;
  onLoginClick: () => void;
  onCartClick: () => void;
  onTodoClick: () => void;
  onProductsClick: () => void;
}

export default function Header({ cartItemsCount = 0, onLoginClick, onCartClick, onTodoClick, onProductsClick }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    if (value.length > 0) {
      const filtered = dailyGroceries.filter(product =>
        product.name.toLowerCase().includes(value.toLowerCase()) ||
        product.category.toLowerCase().includes(value.toLowerCase())
      );
      setSearchResults(filtered.slice(0, 6));
    } else {
      setSearchResults([]);
    }
  };

  const handleSearchFocus = () => {
    setIsSearchFocused(true);
    if (searchQuery.length > 0) {
      const filtered = dailyGroceries.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setSearchResults(filtered.slice(0, 6));
    }
  };

  const handleAddToCart = (product: Product) => {
    toast({
      title: "✅ Item Added Successfully!",
      description: `${product.name} has been added to your cart`,
      duration: 2000,
    });
    setSearchQuery(product.name);
    setSearchResults([]);
    setIsSearchFocused(false);
  };

  const handleSearchBlur = () => {
    // Delay to allow click on suggestions
    setTimeout(() => {
      setIsSearchFocused(false);
      setSearchResults([]);
    }, 200);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      {/* Top Row - Logo and Actions */}
      <div className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-primary">
            <ShoppingCart className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="hidden sm:block">
            <h1 className="text-2xl font-bold">Smart Cart AI</h1>
          </div>
        </div>

        {/* Center Search Bar */}
        <div className="relative flex-1 max-w-2xl mx-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search daily groceries..."
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              onFocus={handleSearchFocus}
              onBlur={handleSearchBlur}
              className={cn(
                "pl-12 pr-4 h-12 text-base transition-all duration-300 rounded-xl border-2",
                isSearchFocused && "search-focus border-primary shadow-primary/20 shadow-lg"
              )}
            />
          </div>
          
          {/* Search Suggestions */}
          {isSearchFocused && searchResults.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-card border-2 border-primary/20 rounded-xl shadow-xl z-50 max-h-80 overflow-y-auto">
              <div className="p-2">
                <p className="text-xs text-muted-foreground mb-2 px-2">Daily Groceries</p>
                {searchResults.map((product) => (
                  <button
                    key={product.id}
                    className="w-full px-4 py-3 text-left hover:bg-primary/5 transition-all duration-200 flex items-center justify-between rounded-lg group"
                    onClick={() => handleAddToCart(product)}
                  >
                    <div className="flex-1">
                      <p className="font-medium group-hover:text-primary transition-colors">{product.name}</p>
                      <p className="text-sm text-muted-foreground">{product.category}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-primary">${product.price}</p>
                      <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                        <span className="text-xs">+</span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Actions */}
        <div className="flex items-center space-x-3">
          {/* Todo List */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="relative hover:bg-primary/10 hover:text-primary transition-all duration-200 hover:scale-105"
            onClick={onTodoClick}
          >
            <ClipboardList className="h-5 w-5" />
            <span className="hidden sm:inline ml-2 font-medium">Todo</span>
          </Button>

          {/* Cart */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="relative hover:bg-primary/10 hover:text-primary transition-all duration-200 hover:scale-105"
            onClick={onCartClick}
          >
            <ShoppingCart className="h-5 w-5" />
            <span className="hidden sm:inline ml-2 font-medium">Cart</span>
            {cartItemsCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center text-xs animate-pulse"
              >
                {cartItemsCount}
              </Badge>
            )}
          </Button>

          {/* Login */}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onLoginClick} 
            className="hidden sm:flex hover:bg-primary hover:text-primary-foreground transition-all duration-200 hover:scale-105 font-medium"
          >
            <User className="h-4 w-4 mr-2" />
            Sign In
          </Button>

          {/* Mobile Menu */}
          <Button
            variant="outline"
            size="sm"
            className="md:hidden hover:bg-primary hover:text-primary-foreground transition-all duration-200"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Bottom Row - Navigation */}
      <div className="border-t bg-background/80">
        <div className="container">
          <nav className="hidden md:flex items-center justify-center space-x-8 py-3">
            <a href="#home" className="text-base font-medium hover:text-primary transition-all duration-200 hover:scale-105 relative group">
              Home
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full"></span>
            </a>
            <button 
              onClick={onProductsClick}
              className="text-base font-medium hover:text-primary transition-all duration-200 hover:scale-105 relative group"
            >
              Products
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full"></span>
            </button>
            <a href="#about" className="text-base font-medium hover:text-primary transition-all duration-200 hover:scale-105 relative group">
              About
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full"></span>
            </a>
          </nav>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <nav className="container py-4 space-y-3">
            <a href="#home" className="block text-sm font-medium hover:text-primary transition-colors">
              Home
            </a>
            <a href="#features" className="block text-sm font-medium hover:text-primary transition-colors">
              Features
            </a>
            <a href="#products" className="block text-sm font-medium hover:text-primary transition-colors">
              Products
            </a>
            <a href="#about" className="block text-sm font-medium hover:text-primary transition-colors">
              About
            </a>
            <Button variant="outline" size="sm" onClick={onLoginClick} className="w-full justify-start">
              <User className="h-4 w-4 mr-2" />
              Sign In
            </Button>
          </nav>
        </div>
      )}
    </header>
  );
}