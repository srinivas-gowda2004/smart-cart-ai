import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Cpu, 
  Zap, 
  CreditCard, 
  Sparkles,
  ShoppingBag,
  Scan,
  Clock,
  Shield
} from "lucide-react";

const features = [
  {
    icon: Cpu,
    title: "AI-powered detection",
    description: "Raspberry Pi streams item events directly into your cart in real time.",
    badge: "Smart Tech"
  },
  {
    icon: Zap,
    title: "Instant add",
    description: "Every scan or detection adds the item automatically with smooth feedback.",
    badge: "Lightning Fast"
  },
  {
    icon: CreditCard,
    title: "In-app checkout",
    description: "Pay in the app and walk out—no more waiting in long lines.",
    badge: "Seamless"
  },
  {
    icon: Sparkles,
    title: "Delightful animations",
    description: "Subtle motion and micro-interactions make the experience feel alive.",
    badge: "Beautiful"
  },
  {
    icon: ShoppingBag,
    title: "Smart Cart Management",
    description: "Intelligent cart organization with quantity updates and easy item removal.",
    badge: "Organized"
  },
  {
    icon: Scan,
    title: "Barcode Recognition",
    description: "Advanced scanning technology for accurate product identification.",
    badge: "Precise"
  },
  {
    icon: Clock,
    title: "Real-time Sync",
    description: "Instant synchronization between devices and cloud storage.",
    badge: "Live"
  },
  {
    icon: Shield,
    title: "Secure Payments",
    description: "Bank-grade security with encrypted payment processing via Razorpay.",
    badge: "Protected"
  }
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-24 bg-gradient-card">
      <div className="container px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Everything you need to shop smarter
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Built for speed, accuracy, and a beautiful experience.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <Card 
                key={index}
                className="group hover:shadow-card transition-all duration-300 hover:-translate-y-1 bg-gradient-card border-0"
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                      <IconComponent className="h-6 w-6 text-primary" />
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {feature.badge}
                    </Badge>
                  </div>
                  <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <p className="text-sm text-muted-foreground">
            © 2025 Smart Cart AI. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  );
}